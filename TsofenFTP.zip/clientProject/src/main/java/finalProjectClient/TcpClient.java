package finalProjectClient;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

import myUtil.BaseRequest;
import myUtil.Request;
import myUtil.RequestFactory;

public class TcpClient {
	private static String serverIP = "127.0.0.1";
	private static int serverPort = 5555;
	private static DataOutputStream dos = null;
	private static DataInputStream dis = null;
	public static String pathS = "Server Files\\";
	public static String pathC = "Client Files\\";

	public static void main(String[] args) {
		System.out.println("Client starting");

		try {

			Socket socket = new Socket(serverIP, serverPort);
			System.out.println("Connected to server " + serverIP + ":" + serverPort);
			OutputStream os = socket.getOutputStream();
			dos = new DataOutputStream(os);

			InputStream is = socket.getInputStream();
			dis = new DataInputStream(is);

			// read what user enter
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			while (true) {
				
				try {
					int i = 0;

					System.out.println("Choose an option\n" + "        1. Download File\n" + "        2. Upload  File\n"
							+ "        3. List Files\n" + "        4. Delete File");

					i = checkInput(br);
		

					// handle list files request
					Request req = new Request(4);

					BaseRequest requestCreator = RequestFactory.create(i,br);

					if (requestCreator != null) {
						// add properties
						req = requestCreator.getRequest();

						System.out.println("request :" + req.toJSON().toString());

						// write to client
						dos.writeUTF(req.toJSON().toString());
						System.out.println("message sent");

					}

					/// show results

					String result = requestCreator.getResult(dis.readUTF());

					if (!result.isEmpty()) {
						System.out.println(result);
					}
				} catch (Exception e) {
					break;
				}

				
			}
			
			// Close resources
			socket.close();
			dos.close();
			dis.close();
		
			

		} catch (IOException e) {
			System.out.println("Connection Refused !!!");
			
		}
	}

	private static int checkInput(BufferedReader br) throws IOException {
		int i;
		do {
			try {
				i = Integer.parseInt(br.readLine());

				if (!(1 <= i && i <= 4)) {
					System.out.println("        Please Check your Input!");
				}
			} catch (NumberFormatException ex) {
				System.out.println("        Input should be a Number. Please Try again!");
				i = -1;
			}
		} while (!(1 <= i && i <= 4));

		return i;
	}

}
