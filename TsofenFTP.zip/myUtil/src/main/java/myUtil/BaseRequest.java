package myUtil;

public interface BaseRequest {
	
	
	public Request getRequest();
	
	public String getResult (String str);


}
