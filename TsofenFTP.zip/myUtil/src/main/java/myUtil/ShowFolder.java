package myUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.Locale;

public class ShowFolder extends BaseAction {
	

	Response res = new Response(null, 0);
	

		
		public ShowFolder(Request request) {
		super(request);
	}

	


		File file = new File("Server Files");
		File[] files =null;
		


		@Override
		public Response doWork() {

			
			file = new File(this.getRequest().getFilePath());
			files = file.listFiles();
		
			
			
			String fileNameString = String.join(", ", listFiles(files));
		
			
			
	
			
			res.setBody(fileNameString);
			
			res.setContentType("String");
			
			
			if (files.length <1) {
				res.setResponseCode(404);
			}
			else
				res.setResponseCode(200);
			
			
			
			return res;
		
		}
		
		private  List <String> listFiles(File[] files) {
			
			List <String>  fileNames = new ArrayList<String>();
			
			for(File f: files) {
				if(! f.isDirectory()) 
					
					fileNames.add(f.getName()); 
			}
			return fileNames;
		
			
		}
		
	
	
		

	

}
