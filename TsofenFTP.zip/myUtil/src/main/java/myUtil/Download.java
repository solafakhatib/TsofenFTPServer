package myUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Download extends BaseAction {
	private  static String fileName="";
	File file = new File("Server Files");
	Response res = null;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		setFileName(fileName);
		
	}

	public Download(Request request,String fileName) {
		super(request);
		this.fileName=fileName;
	}

	@Override
	public Response doWork() {
		// decide about file name
		res = new Response(" ", this.getRequest().getRequestId());
		fileName = this.getRequest().getFilePath();

		file = new File("Server Files\\" + fileName);

		String data = sendFile(file);
		res.setBody(data);
		res.setContentType("string");

		return res;
	}

	private String sendFile(File file) {

		String filedata = "";
		byte[] data;
		FileInputStream fis = null;
		FileOutputStream fos = null;

		try {

			// file = new File(fileName);

			if (file.isFile()) {
				fis = new FileInputStream(file);

				data = new byte[(int) file.length()];
				fis.read(data);
				fis.close();
				filedata = new String(data);
				res.setResponseCode(200);

			} else {
				// not found
				res.setResponseCode(404);
			}
		} catch (Exception e) {
			res.setResponseCode(500);
		}

		return filedata;
	}

}
