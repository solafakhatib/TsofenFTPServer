package myUtil;

import java.io.File;

import java.io.FileOutputStream;

public class Upload extends BaseAction {

	private  static String fileName="";

	public static FileOutputStream fos = null;
	Response res = new Response(null, 0);

	File file = new File("Client Files");

	public Upload(Request request, String fileName) {
		super(request);
		this.fileName=fileName;

	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public Response doWork() {
		res = new Response(" ", this.getRequest().getRequestId());

		fileName = this.getRequest().getFilePath();

		file = new File("Server Files\\" + fileName);

		res.setBody(receiveFile(this.getRequest().getBody(), "Server Files\\"));
		res.setContentType("string");

		return res;

	}

	public String receiveFile(String data, String path) {
		String str = "failed";

		try {

			String filedata = "";
			filedata = data;
			if (filedata.equals("")) {
				str = ("No Such File");
				res.setResponseCode(404);

			} else {
				fos = new FileOutputStream(path + fileName);
				fos.write(filedata.getBytes());
				fos.close();
				str = ("file uploaded");
				res.setResponseCode(200);
			}
		} catch (Exception e) {
		}

		return str;
	}

}
