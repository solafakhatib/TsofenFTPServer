package myUtil;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;

public class DownloadRequest implements BaseRequest {

	public static FileOutputStream fos = null;

	 static String filename = "";
	Response res1 = null;
	public static BufferedReader _br;
	
	

	public DownloadRequest(String filename) {
		super();
		this.filename=filename;
		
	}

	@Override
	public Request getRequest() {
		Request req = new Request(1);
		
		// ask for file name
		
		req.setFilePath(filename);
		req.setAction("download");
		req.setBody(" ");
		req.setContentType("String");

		filename = req.getFilePath();

		return req;
	}

	@Override
	public String getResult(String str) {

		res1 = new Response(" ", 1);
		
		// recevie file request
		res1.fromJSON(str);

		return receiveFile(res1.getBody(), "Client Files\\") + " response Code :" + res1.getResponseCode();
	}

	public String receiveFile(String data, String path) {

		String str = "Failed to Download";
		try {

			String filedata = "";
			filedata = data;
			if (filedata.equals("")) {
				str = "No Such File";
				res1.setResponseCode(404);
			} else {
				fos = new FileOutputStream(path + filename);
				fos.write(filedata.getBytes());
				fos.close();
				str = "file downloaded";
				res1.setResponseCode(200);
			}
		} catch (Exception e) {
			res1.setResponseCode(500);
		}
		return str;
	}
	
	private static String inputFileName() {
		String fileName=null;
		
		try {
			
				  System.out.println("Enter the FileName which you want to Download\n"
							);
		
				fileName = _br.readLine();
				
//				request1.setFilePath(fileName);
//				request1.setAction("download");

		}
		catch(IOException ex) {
			ex.printStackTrace();
		}
		return fileName;
	}
	
	

}
