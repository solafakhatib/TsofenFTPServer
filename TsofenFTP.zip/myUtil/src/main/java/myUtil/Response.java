package myUtil;

import org.json.JSONObject;

public class Response extends Massage {

	private int ResponseCode;

	public Response(String body, int requestId) {
		super(requestId);
		setBody(body);

	}

	public int getResponseCode() {
		return ResponseCode;
	}

	public void setResponseCode(int responseCode) {
		ResponseCode = responseCode;
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		getHeader().put("RequestId", getRequestId());
		getHeader().put("ContentType", getContentType());
		getHeader().put("ResponseCode", ResponseCode);
		json.put("header", getHeader());
		json.put("body", getBody());

		return json;
	}

	public void fromJSON(String jsonStr) {
		JSONObject json = new JSONObject(jsonStr);

		this.setHeader(json.getJSONObject("header"));
		this.setBody(json.getString("body"));
		this.setRequestId(getHeader().getInt("RequestId"));
		this.setContentType(getHeader().getString("ContentType"));
		this.setResponseCode(getHeader().getInt("ResponseCode"));

	}

	@Override
	public String toString() {
		return "Response [ResponseCode=" + ResponseCode + ", getHeader()=" + getHeader() + ", getBody()=" + getBody()
				+ ", getRequestId()=" + getRequestId() + ", getContentType()=" + getContentType() + ", toString()="
				+ super.toString() + "]";
	}
	
	

}