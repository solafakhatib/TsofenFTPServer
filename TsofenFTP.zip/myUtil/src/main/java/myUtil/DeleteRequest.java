package myUtil;

public class DeleteRequest implements BaseRequest {
	 static String filename = "";
	
	public DeleteRequest(String filename) {
		super();
		this.filename=filename;
		
	}


	@Override
	public Request getRequest() {
		Request req = new Request(1);
		req.setFilePath(filename);
		req.setAction("delete");
		req.setBody(" ");
		req.setContentType("String");

		return req;

	}

	@Override
	public String getResult(String str) {
		Response res1 = new Response("", 2);

		res1.fromJSON(str);
		String r = res1.getBody() + " response Code : " + res1.getResponseCode();
		return r;
	}

}
