package myUtil;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MyFile {
	private static  DataOutputStream dos=null;
    private static DataInputStream dis=null ;
    public static FileOutputStream fos = null;
    public static String pathS="Server Files\\";
    public static String pathC="Client Files\\";
	

	public static void receiveFile2(String data, String path){
		try{
			
			String filename="file1",filedata="";	
//			System.out.println("Enter the filename: ");
//			filename = br.readLine();
//			dos.writeUTF("DOWNLOAD_FILE");
			dos.writeUTF(filename);
			filedata = data;
		        if(filedata.equals(""))
			{
			  	System.out.println("No Such File");
			}
			else
			{
				fos = new FileOutputStream(path+filename+".txt");
				fos.write(filedata.getBytes());
				fos.close();
				System.out.println("file downloaded111");
			}			
		}
		catch(Exception e)
		{
		}
	}
	
	

}
