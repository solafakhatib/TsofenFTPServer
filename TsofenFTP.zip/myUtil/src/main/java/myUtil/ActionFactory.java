package myUtil;

public class ActionFactory {
		
		public static BaseAction create(Request req,String path) {
			
			
			
			BaseAction action = null;
			String actionType = req.getAction().toLowerCase();  
			switch (actionType) {
			case "download":
				action = new Download(req, path);
				break;		
			case "upload":
				action = new Upload(req,path);
				break;	
			case "showfolder":
				action = new ShowFolder(req);
				break;
			case "delete" :
				action = new Delete(req,path);
				break;
			default:
//				action = UnrecognizedAction();
				break;
			}
			
			return action;
		}

	


}
