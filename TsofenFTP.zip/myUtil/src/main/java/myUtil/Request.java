package myUtil;


import org.json.JSONObject;

public class Request extends Massage{
	
	private String filePath;
	private String Action;

	

	public Request(int requestId) {
		super(requestId);
		// TODO Auto-generated constructor stub
	}



	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}



	public String getAction() {
		return Action;
	}

	public void setAction(String action) {
		Action = action;
	}


	
	public JSONObject toJSON(){
	
		JSONObject json = new JSONObject();
		getHeader().put("RequestId",getRequestId());
		getHeader().put("ContentType",getContentType());
		getHeader().put("filePath", filePath);
		getHeader().put("Action", Action);
		json.put("header", getHeader());
		json.put("body",getBody());

		return json ;
	}

	public void fromJSON(String jsonStr) {
         JSONObject json = new JSONObject(jsonStr);
	this.setHeader(json.getJSONObject("header"));
	this.setBody(json.getString("body"));
	this.setRequestId(getHeader().getInt("RequestId"));
	this.setFilePath(getHeader().getString("filePath"));
	this.setContentType(getHeader().getString("ContentType"));
	this.setAction(getHeader().getString("Action"));;

		
	}

	@Override
	public String toString() {
		return "Request [header=" + getHeader() + ", body=" + getBody() + ", RequestId=" + getRequestId()+ ", filePath=" + filePath
				+ ", ContentType=" + getContentType() + ", Action=" + Action + "]";
	}




	
	

	
}