package myUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class UploadRequest implements BaseRequest {
	

	 static String filename = "";
	 Response res1 = null;
	 
	 

		public UploadRequest(String filename) {
			super();
			this.filename=filename;
			
		}

	@Override
	public Request getRequest() {
		Request req = new Request(1);
		req.setFilePath(filename);
		req.setAction("upload");
		File file = new File("Client Files\\" + req.getFilePath());
		String data = sendFileU(file);
		req.setBody(data);

		req.setContentType("String");
		return req;
	}

	private static String sendFileU(File file) {

		String filedata = "";
		byte[] data;
		FileInputStream fis = null;
		FileOutputStream fos = null;

		try {

			// file = new File(fileName);

			if (file.isFile()) {
				fis = new FileInputStream(file);

				data = new byte[(int) file.length()];
				fis.read(data);
				fis.close();
				filedata = new String(data);

			} else {
				// not found
			}
		} catch (Exception e) {

		}

		return filedata;
	}

	@Override
	public String getResult(String str) {
		Response res1 = new Response("", 2);
		res1.fromJSON(str);

		String r = res1.getBody() + " response Code : " + res1.getResponseCode();
		return r;
	}

}
