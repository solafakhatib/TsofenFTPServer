package myUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;
import java.util.List;

public class ShowFolderRequest implements BaseRequest {

	private  StringBuilder sb = new StringBuilder();

	@Override
	public Request getRequest() {
		Request req = new Request(1);
		req.setFilePath("Server Files");
		req.setAction("showFolder");
		req.setBody(" ");
		req.setContentType("String");
		return req;
	}

	@Override
	public String getResult(String str) {
		Response res = new Response(" ", 1);
		res.fromJSON(str);
		List<String> myFilesList = new ArrayList<String>(Arrays.asList(res.getBody().split(","))); 
			
		sb.append("Total Files in folder - " + myFilesList.size() + "\n");
		listFiles(myFilesList);
		

		return sb.toString();
	}
	private  void listFiles(List<String> files) {
		int k = 0;
		
		sb.append("\n        +---------+----------------------+\n");			
		Formatter formatter = new Formatter(sb);
		//formats the fields to create table like structure while displaying on console
		formatter.format("        | %-7s | %-20s |\n", "Sr No", "Filename");			
		sb.append("        +---------+----------------------+\n");
		
		for(String f: files) {
				formatter.format("        | %-7s | %-20s |\n", ++k, f);
		}
		
		sb.append("        +---------+----------------------+\n\n        ");
		
		formatter.close();
		
		
	}

}
