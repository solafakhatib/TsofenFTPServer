package myUtil;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;                                        
public class RequestFactory {
	
	public static BufferedReader _br;
	
	public static String fileName;
	
	
	
	
	public static BaseRequest create(int i , BufferedReader br ) {
		
		BaseRequest request = null;
		_br =br;
		
		  
		switch (i) {
		case 1:
			fileName=inputFileName();
			//request = new DownloadRequest(fileName);
			request = new DownloadRequest(fileName);
			
			break;		
		case 2:
			fileName=inputFileName();
			request = new UploadRequest(fileName);
			break;	
		case 3:
			request = new ShowFolderRequest();
			break;
		case 4 :
			fileName=inputFileName();
			request = new DeleteRequest(fileName);
		default:
//			action = UnrecognizedAction();
			break;
		}
		
		return request;
	}
	
	public static String inputFileName() {
		String path=null;
	
		try {
			
				  System.out.println("Enter the FileName \n"
							);
		
				path = _br.readLine();


		}
		catch(IOException ex) {
			ex.printStackTrace();
		}
		return path;
	}
	





}
