package myUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class Massage {
	// inhertance class
	private JSONObject header = new JSONObject();
	private String body;
	private int requestId;
	private String ContentType;


	public Massage(int requestId) {
		super();
		this.requestId = requestId;
	}



	public JSONObject getHeader() {
		return header;
	}

	public void setHeader(JSONObject header) {
		this.header = header;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getContentType() {
		return ContentType;
	}

	public void setContentType(String contentType) {
		ContentType = contentType;
	}

	@Override
	public String toString() {
		return "Massage [header=" + header + ", body=" + body + ", requestId=" + requestId + ", ContentType="
				+ ContentType +  "]";
	}
	
	public boolean isJSONValid(String test) {
	    try {
	        new JSONObject(test);
	    } catch (JSONException ex) {
	       
	        try {
	            new JSONArray(test);
	        } catch (JSONException ex1) {
	            return false;
	        }
	    }
	    return true;
	}
	
public abstract JSONObject toJSON();

	
public abstract void fromJSON(String jsonStr);

	

}
