package myUtil;

public abstract class BaseAction {
	private Request request;
	
	public BaseAction(Request request) {
		super();
		this.request = request;
	}

	
	
	public Request getRequest() {
		return request;
	}


	public void setRequest(Request request) {
		this.request = request;
	}
	


	public abstract Response doWork();

}
