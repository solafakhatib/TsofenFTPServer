package myUtil;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.util.Formatter;

public class Delete extends BaseAction{
	
	private  static String fileName="";
	Response res = new Response(null, 0);
	File[] files =null;
	File file = new File("Server Files");
	

	public Delete(Request request,String fileName) {
		super(request);
		this.fileName=fileName;
	}
	

	@Override
	public Response doWork() {
		res = new Response(" ", this.getRequest().getRequestId());
	
		fileName ="Server Files\\" + this.getRequest().getFilePath();		
		String data =deleteFile(); 

		res.setBody(data);
		res.setContentType("string");	

				return res;
		
	}

	public String deleteFile() {
		String str;
		boolean successed =true;
		try {
            successed= Files.deleteIfExists(
                Paths.get(fileName));
        }
        catch (NoSuchFileException e) {
            str = "No such file/directory exists";
            res.setResponseCode(404);
              
        }
        catch (DirectoryNotEmptyException e) {
           str ="Directory is not empty.";
           res.setResponseCode(500);
        }
        catch (IOException e) {
            str="Invalid permissions.";
            res.setResponseCode(500);
        }
		if (successed) {
			str="Deletion successful.";
			res.setResponseCode(200);
			
		} else {
			str="File doesn't exists";
			res.setResponseCode(404);
		}
 
   
    	return str;
	}
	
	


	

}
