package finalProjectServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class TcpServer {
	private static int port = 5555;

	public static void main(String[] args) {
		System.out.println("Server starting....");

		try {
			ServerSocket serverSocket = new ServerSocket(port); // approving
																// port
			System.out.println("Connected ...");

			System.out.println("Waiting for client message");

			while (true) {
				Socket socket = serverSocket.accept(); // listening to client
														// messages

				// create a new thread object
				Thread t = new ClientHandler(socket);

				// Invoking the start() method
				t.start();

			}

		} catch (IOException e) {
			e.printStackTrace();

		}

		System.out.println("Server shutdown");
	}

}