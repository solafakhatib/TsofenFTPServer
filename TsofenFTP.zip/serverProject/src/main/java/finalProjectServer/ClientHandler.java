package finalProjectServer;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import myUtil.ActionFactory;
import myUtil.BaseAction;
import myUtil.Log;
import myUtil.Request;
import myUtil.Response;

public class ClientHandler extends Thread {

	final DataInputStream dis;
	final DataOutputStream dos;
	final Socket s;

	// Constructor
	public ClientHandler(Socket s) throws IOException {
		this.s = s;
		InputStream is = s.getInputStream();
		this.dis = new DataInputStream(is);

		OutputStream os = s.getOutputStream();
		this.dos = new DataOutputStream(os);

	}

	@Override
	public void run() {
		Log myLog = null;
		try {
			myLog = new Log("log.txt");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		while (true) {

			// handle request
			try {
				Request req = new Request(1);
				req.fromJSON(dis.readUTF());

				myLog.logger.info("info msg  :" + req.toString());
				Response res = null;

				BaseAction action = ActionFactory.create(req, req.getFilePath());
				
				if (action != null) {
					// add properties

					res = action.doWork();

//					System.out.println(res.toJSON().toString());

					// write to client
					dos.writeUTF(res.toJSON().toString());

				}
			} catch (IOException e) {
				break;
			}
		}

		try {
			// closing resources
			this.dis.close();
			this.dos.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}